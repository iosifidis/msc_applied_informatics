import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Main game loop for platform behavior.
 * 
 * @author Efstathios Iosifidis 
 * @version 0.1
 */
public class Platform extends Actor
{

    public void act()
    {
        // Add your action code here.
    }
}
