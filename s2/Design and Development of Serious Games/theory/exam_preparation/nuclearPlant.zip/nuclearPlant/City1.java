import greenfoot.*;

public class City1 extends World {
    public City1() {
        super(800, 600, 1);
        prepare();
    }
    
    private void prepare() {
        // *** ΠΡΟΣΘΗΚΗ ΤΟΥ STATUS DISPLAY ***
        addObject(new StatusDisplay(), 150, 20); // Εμφανίζεται πάνω αριστερά
        
        // Τοποθετούμε το ασθενοφόρο και τα παιδιά όπως πριν
        Ambulance ambulance = new Ambulance();
        addObject(ambulance, 100, 300);
        
        for (int i=0; i < 4; i++) {
            addObject(new Child(), Greenfoot.getRandomNumber(getWidth()), Greenfoot.getRandomNumber(getHeight()));
        }
        
        for (int i = 0; i < 2; i++) {
            addObject(new Tree(), Greenfoot.getRandomNumber(getWidth()), Greenfoot.getRandomNumber(getHeight()));
            addObject(new House(), Greenfoot.getRandomNumber(getWidth()), Greenfoot.getRandomNumber(getHeight()));
        }
    }
}