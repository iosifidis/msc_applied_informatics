import greenfoot.*;

public class Child extends Actor {
    public Child() {
        // Μπορείτε να κάνετε την εικόνα λίγο μικρότερη αν χρειαστεί
        // getImage().scale(30, 40);
    }
}