import greenfoot.*;

// Αυτή η κλάση χρησιμοποιείται για να ομαδοποιήσει τα εμπόδια.
// Δεν χρειάζεται να κάνει τίποτα.
public class Obstacle extends Actor {
}