import greenfoot.*;

public class Tree extends Obstacle {
    public Tree() {
        // Εδώ μπορείτε να βάλετε την εικόνα σας.
    }
}