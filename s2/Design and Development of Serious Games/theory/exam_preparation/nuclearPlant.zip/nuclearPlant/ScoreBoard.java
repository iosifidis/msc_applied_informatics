import greenfoot.*;

public class ScoreBoard extends Actor {

    private static final int BOARD_WIDTH = 400;
    private static final int BOARD_HEIGHT = 200;

    /**
     * Δημιουργεί έναν πίνακα σκορ με τίτλο και πόντους.
     * Το κείμενο κεντράρεται αυτόματα.
     */
    public ScoreBoard(String title, int score) {
        GreenfootImage image = new GreenfootImage(BOARD_WIDTH, BOARD_HEIGHT);

        // 1. Σχεδίαση του φόντου
        // Χρησιμοποιούμε την κλάση greenfoot.Color
        image.setColor(new greenfoot.Color(50, 50, 50, 180)); // Ημιδιαφανές γκρι
        image.fill(); // Γεμίζει ολόκληρη την εικόνα

        // 2. Ρυθμίσεις για τον τίτλο
        greenfoot.Font titleFont = new greenfoot.Font("Arial", true, false, 48);
        image.setFont(titleFont);
        image.setColor(greenfoot.Color.WHITE);
        
        // Κεντράρουμε τον τίτλο οριζόντια
        int titleWidth = getCenteredX(title, image);
        image.drawString(title, titleWidth, 80);

        // 3. Ρυθμίσεις για το σκορ
        greenfoot.Font scoreFont = new greenfoot.Font("Arial", false, false, 36);
        image.setFont(scoreFont);

        // Κεντράρουμε το σκορ οριζόντια
        String scoreText = "Score: " + score;
        int scoreWidth = getCenteredX(scoreText, image);
        image.drawString(scoreText, scoreWidth, 150);
        
        setImage(image);
    }
    
    /**
     * Βοηθητική μέθοδος για να υπολογίσει τη συντεταγμένη x ώστε το κείμενο να είναι κεντραρισμένο.
     * @return Τη συντεταγμένη Χ για την drawString.
     */
    private int getCenteredX(String text, GreenfootImage context) {
        // Δημιουργούμε μια προσωρινή εικόνα μόνο για να μετρήσουμε το πλάτος του κειμένου
        GreenfootImage temp = new GreenfootImage(text, context.getFont().getSize(), context.getColor(), new greenfoot.Color(0,0,0,0));
        return (context.getWidth() - temp.getWidth()) / 2;
    }
}