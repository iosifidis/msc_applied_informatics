import greenfoot.*;

/**
 * Η κλάση Ambulance αναπαριστά το όχημα που ελέγχει ο παίκτης.
 * Ο σκοπός του είναι να συλλέξει παιδιά αποφεύγοντας τα εμπόδια, ενώ
 * το σκορ και ο αριθμός των παιδιών εμφανίζονται συνεχώς στην οθόνη.
 * Η εικόνα του οχήματος αλλάζει ανάλογα με την κατεύθυνση κίνησης.
 */
public class Ambulance extends Actor {
    // --- Μεταβλητές για τη λογική του παιχνιδιού ---
    private int speed = 4;
    private int level = 1;
    // Οι static μεταβλητές διατηρούν την τιμή τους μεταξύ των επιπέδων.
    private static int score;
    private static int childrenCollected;

    // --- Μεταβλητές για την εμφάνιση ---
    // Μια αναφορά στον πίνακα που δείχνει το τρέχον σκορ.
    private StatusDisplay statusDisplay;
    // Οι εικόνες για κάθε κατεύθυνση.
    private GreenfootImage imageUp, imageDown, imageLeft, imageRight;

    /**
     * Constructor: Εκτελείται όταν δημιουργείται ένα νέο αντικείμενο Ambulance.
     * Απλά φορτώνει τις εικόνες κατεύθυνσης. Ο μηδενισμός του σκορ θα γίνει
     * όταν το αντικείμενο προστεθεί στον κόσμο.
     */
    public Ambulance() {
        imageDown = new GreenfootImage("ambulance1.png");
        imageLeft = new GreenfootImage("ambulance2.png");
        imageRight = new GreenfootImage("ambulance3.png");
        imageUp = new GreenfootImage("ambulance4.png");
        
        // Ορίζουμε μια αρχική εικόνα για το ασθενοφόρο.
        setImage(imageDown);
    }

    /**
     * Η μέθοδος addedToWorld καλείται αυτόματα από το Greenfoot
     * μόλις το αντικείμενο προστεθεί σε έναν κόσμο.
     * Είναι το ιδανικό μέρος για να κάνουμε αρχικοποιήσεις που εξαρτώνται από τον κόσμο.
     */
    protected void addedToWorld(World world) {
        // Αν μπούμε στον κόσμο City1, σημαίνει ότι το παιχνίδι ξεκινάει,
        // οπότε μηδενίζουμε το σκορ και τα παιδιά που έχουν συλλεχθεί.
        if (world instanceof City1) {
            score = 0;
            childrenCollected = 0;
        }

        // Βρίσκουμε το αντικείμενο StatusDisplay που ήδη υπάρχει στον κόσμο
        // και κρατάμε μια αναφορά σε αυτό για να μπορούμε να το ενημερώνουμε.
        statusDisplay = world.getObjects(StatusDisplay.class).get(0);
        
        // Μόλις μπούμε, ενημερώνουμε την οθόνη με τις τρέχουσες τιμές.
        statusDisplay.updateDisplay(score, childrenCollected);
    }
    
    /**
     * Η μέθοδος act εκτελείται συνεχώς όσο το παιχνίδι τρέχει.
     * Καλεί τις επιμέρους μεθόδους που ελέγχουν τη λειτουργία του παιχνιδιού.
     */
    public void act() {
        checkKeypress();
        lookForCollision();
        lookForChild();
        checkNextLevel();
    }
    
    /**
     * Ελέγχει ποιο βελάκι πατιέται και κινεί το ασθενοφόρο ανάλογα,
     * αλλάζοντας και την εικόνα του για να "κοιτάει" προς τη σωστή κατεύθυνση.
     */
    public void checkKeypress() {
        if (Greenfoot.isKeyDown("up")) {
            setImage(imageUp);
            setLocation(getX(), getY() - speed);
        } else if (Greenfoot.isKeyDown("down")) {
            setImage(imageDown);
            setLocation(getX(), getY() + speed);
        } else if (Greenfoot.isKeyDown("left")) {
            setImage(imageLeft);
            setLocation(getX() - speed, getY());
        } else if (Greenfoot.isKeyDown("right")) {
            setImage(imageRight);
            setLocation(getX() + speed, getY());
        }
    }
    
    /**
     * Ελέγχει για πρόσκρουση με κάποιο εμπόδιο. Αν υπάρξει, εμφανίζει
     * το τελικό μήνυμα "Game Over" και σταματάει το παιχνίδι.
     */
    public void lookForCollision() {
        if (isTouching(Obstacle.class)) {
            ScoreBoard gameOverBoard = new ScoreBoard("Game Over", score);
            getWorld().addObject(gameOverBoard, getWorld().getWidth() / 2, getWorld().getHeight() / 2);
            Greenfoot.stop();
        }
    }
    
    /**
     * Ελέγχει αν το ασθενοφόρο αγγίζει κάποιο παιδί. Αν ναι, το αφαιρεί,
     * αυξάνει το σκορ και τα παιδιά που έχουν συλλεχθεί, και ενημερώνει την οθόνη.
     */
    public void lookForChild() {
        if (isTouching(Child.class)) {
            removeTouching(Child.class);
            score += 50;
            childrenCollected++;
            
            // Βεβαιωνόμαστε ότι έχουμε βρει το statusDisplay πριν το χρησιμοποιήσουμε.
            if (statusDisplay != null) {
                statusDisplay.updateDisplay(score, childrenCollected);
            }
        }
    }
    
    /**
     * Ελέγχει αν έχουν ολοκληρωθεί οι συνθήκες για να προχωρήσει το παιχνίδι
     * στο επόμενο επίπεδο ή για να τελειώσει με νίκη.
     */
    public void checkNextLevel() {
        // Μετάβαση από το επίπεδο 1 στο 2
        if (level == 1 && childrenCollected == 4) {
            Greenfoot.setWorld(new City2(this));
        }
        
        // Νίκη στο τέλος του επιπέδου 2 (συνολικά παιδιά = 4 από L1 + 11 από L2 = 15)
        if (level == 2 && childrenCollected == 15) {
            ScoreBoard wellDoneBoard = new ScoreBoard("Well Done!", score);
            getWorld().addObject(wellDoneBoard, getWorld().getWidth() / 2, getWorld().getHeight() / 2);
            Greenfoot.stop();
        }
    }
    
    /**
     * Μια βοηθητική μέθοδος που καλείται από τον κόσμο (City2) για να ενημερώσει
     * το ασθενοφόρο σε ποιο επίπεδο βρίσκεται.
     */
    public void setLevel(int newLevel) {
        this.level = newLevel;
    }
}