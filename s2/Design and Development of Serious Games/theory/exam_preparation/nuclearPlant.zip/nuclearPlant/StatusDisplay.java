import greenfoot.*;

public class StatusDisplay extends Actor {
    public StatusDisplay() {
        // Ξεκινάμε με μια αρχική, κενή εικόνα για να μην υπάρχει σφάλμα
        updateDisplay(0, 0); 
    }

    /**
     * Ενημερώνει την εικόνα για να δείχνει τις τρέχουσες τιμές.
     * @param score Το τρέχον σκορ.
     * @param childrenCollected Ο τρέχον αριθμός παιδιών.
     */
    public void updateDisplay(int score, int childrenCollected) {
        String textToShow = "Score: " + score + " | Children: " + childrenCollected;
        
        // Δημιουργούμε μια εικόνα που θα περιέχει μόνο το κείμενό μας
        // Η greenfoot.Color(0, 0, 0, 0) δημιουργεί ένα εντελώς διαφανές φόντο.
        GreenfootImage image = new GreenfootImage(textToShow, 24, greenfoot.Color.WHITE, new greenfoot.Color(0, 0, 0, 0));
        
        setImage(image);
    }
}