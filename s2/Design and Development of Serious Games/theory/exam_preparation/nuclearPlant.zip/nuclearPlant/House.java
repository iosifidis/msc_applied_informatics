import greenfoot.*;

public class House extends Obstacle {
    public House() {
        // Εδώ μπορείτε να βάλετε την εικόνα σας.
    }
}