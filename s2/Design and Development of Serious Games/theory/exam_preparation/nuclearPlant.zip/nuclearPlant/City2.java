import greenfoot.*;

public class City2 extends World {
    public City2(Ambulance ambulance) {    
        super(800, 600, 1);
        prepare(ambulance);
    }
    
    private void prepare(Ambulance ambulance) {
        // *** ΠΡΟΣΘΗΚΗ ΤΟΥ STATUS DISPLAY ΚΑΙ ΕΔΩ ***
        addObject(new StatusDisplay(), 150, 20);

        // Τοποθετούμε το ασθενοφόρο που ήρθε από το προηγούμενο επίπεδο
        addObject(ambulance, 50, getHeight() / 2);
        ambulance.setLevel(2);

        // Προσθήκη 11 παιδιών σε τυχαίες θέσεις
        for (int i = 0; i < 11; i++) {
            addObject(new Child(), Greenfoot.getRandomNumber(getWidth()), Greenfoot.getRandomNumber(getHeight()));
        }
        
              // 4. Προσθήκη νέων εμποδίων
        for (int i = 0; i < 3; i++) {
            addObject(new Tree(), Greenfoot.getRandomNumber(getWidth()), Greenfoot.getRandomNumber(getHeight()));
            addObject(new House(), Greenfoot.getRandomNumber(getWidth()), Greenfoot.getRandomNumber(getHeight()));
        }
    }
}