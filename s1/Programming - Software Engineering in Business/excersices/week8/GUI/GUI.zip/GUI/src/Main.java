
public class Main {

	public static void main(String[] args) {
		
		MyFrame mf1 = new MyFrame();
		
		

	}

}
