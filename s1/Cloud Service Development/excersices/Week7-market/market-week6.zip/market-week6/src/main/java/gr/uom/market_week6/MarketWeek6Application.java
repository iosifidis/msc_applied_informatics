package gr.uom.market_week6;

import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarketWeek6Application {

	public static void main(String[] args) {
		SpringApplication.run(MarketWeek6Application.class, args);
	}

}
