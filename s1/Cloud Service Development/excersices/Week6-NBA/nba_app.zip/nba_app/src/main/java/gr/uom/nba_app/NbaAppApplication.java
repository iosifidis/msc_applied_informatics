package gr.uom.nba_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NbaAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(NbaAppApplication.class, args);
	}

}
