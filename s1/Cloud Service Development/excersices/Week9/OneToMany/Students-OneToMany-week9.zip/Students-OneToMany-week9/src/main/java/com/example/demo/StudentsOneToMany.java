package com.example.demo;

import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentsOneToMany {

	public static void main(String[] args) {
		SpringApplication.run(StudentsOneToMany.class, args);
	}
	
}
