package gr.uom.market_week8;

import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarketWeek8Application {

	public static void main(String[] args) {
		SpringApplication.run(MarketWeek8Application.class, args);
	}

}
