/**
 * 
 */
/**
 * 
 */
module exams {
	requires java.desktop;
}