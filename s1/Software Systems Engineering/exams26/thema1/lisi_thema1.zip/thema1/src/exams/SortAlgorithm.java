package exams;

public interface SortAlgorithm {
	void sort(Object[] array);
}
