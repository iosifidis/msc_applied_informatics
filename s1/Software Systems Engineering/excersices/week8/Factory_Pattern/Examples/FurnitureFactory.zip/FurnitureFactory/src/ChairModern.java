
public class ChairModern extends Chair{
	public void printInfo() {
		System.out.println("A modern chair");
	}
}
