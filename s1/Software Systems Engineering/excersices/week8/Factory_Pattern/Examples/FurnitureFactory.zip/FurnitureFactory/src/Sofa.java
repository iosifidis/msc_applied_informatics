
public abstract class Sofa extends Furniture {
	public abstract void printInfo();
}
