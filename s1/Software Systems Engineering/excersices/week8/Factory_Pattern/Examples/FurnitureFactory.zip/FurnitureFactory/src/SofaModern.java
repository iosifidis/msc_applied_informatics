
public class SofaModern extends Sofa{
	public void printInfo() {
		System.out.println("A modern sofa");
	}
}
