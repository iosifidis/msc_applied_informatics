
public class ChairVictorian extends Chair{
	public void printInfo() {
		System.out.println("A victorian chair");
	}
}
