
public class SofaVictorian extends Sofa{
	public void printInfo() {
		System.out.println("A victorian sofa");
	}
}
