
public class TableModern extends Table{
	public void printInfo() {
		System.out.println("A modern table");
	}
}
