public abstract class Furniture {

	public abstract void printInfo();
}
