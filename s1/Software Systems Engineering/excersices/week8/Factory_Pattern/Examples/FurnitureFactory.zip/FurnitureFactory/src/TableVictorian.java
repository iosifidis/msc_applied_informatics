
public class TableVictorian extends Table{
	public void printInfo() {
		System.out.println("A victorian table");
	}
}
