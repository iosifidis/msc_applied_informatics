
public abstract class Chair extends Furniture {

	@Override
	public abstract void printInfo();

}
