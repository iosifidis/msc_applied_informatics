
public abstract class Table extends Furniture {
	public abstract void printInfo();
}
