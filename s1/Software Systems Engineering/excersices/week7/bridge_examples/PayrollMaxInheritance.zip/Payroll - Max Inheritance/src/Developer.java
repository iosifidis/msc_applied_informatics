
public abstract class Developer extends Employee {

	public Developer(String n) {
		super(n);
	}

	@Override
	public abstract double getPayroll();

}
