
public abstract class Analyst extends Employee {
	public Analyst(String n) {
		super(n);
	}

	@Override
	public abstract double getPayroll();
	
}
